<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bootstrap</title>
</head>
<body>

	<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" /> 
	<!-- Example 1 -->
	<h1>Containers</h1>

	<div class="container">	<pre>

	@media (min-width: 1200px)
	.container {
		width: 1170px;
	}
	@media (min-width: 992px)
	.container {
		width: 970px;
	}
	@media (min-width: 768px)
	.container {
		width: 750px;
	}
	.container {
		padding-right: 15px;
		padding-left: 15px;
		margin-right: auto;
		margin-left: auto;
	}
</pre>
</div>
<hr>

<!-- Example 2 -->
<h1>Rows and Columns</h1>
<pre>
	.row {
		margin-right: -15px;
		margin-left: -15px;
	}	
</pre>
<div class="container">
	<div class="row">
		<div class="col-sm-7">
			<h2>col-sm-7</h2>
		</div>
		<div class="col-sm-5">
			<h2>col-sm-5</h2>
		</div>
	</div>
</div>

<hr>
<!-- Example 3 -->
<h1>Columns of six within parent colums of 8 and 4</h1>
<div class="container">
	<div class="row">
		<div class="col-sm-8">
			<div class="col-sm-6">
				<h3>	
					col-sm-6 within col-sm-8
				</h3>
			</div>
			<div class="col-sm-6">
				<h3>	
					col-sm-6 within col-sm-8
				</h3>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="col-sm-6">
				<h3>	
					col-sm-6 within col-sm-4
				</h3>
			</div>
			<div class="col-sm-6">
				<h3>	
					col-sm-6 within col-sm-4
				</h3>
			</div>
		</div>
	</div>
</div> 


<hr>
<!-- Example 4 -->
<h1>Col md and lg</h1>
<div class="container">
	<div class="row">
		<div class="col-lg-3">
			<h3>col-lg-3</h3>
		</div>	
		<div class="col-lg-3">
			<h3>col-lg-3</h3>
		</div>		
		<div class="col-md-3">
			<h3>col-md-3</h3>
		</div>	
		<div class="col-md-3">
			<h3>col-md-3</h3>
		</div>
	</div>
</div> 

<!-- Example 5 -->
<h1>Multiple Column sizes on one element</h1>
<div class="container">
	<div class="row">
		<div class="col-lg-3 col-xs-3 col-md-12">
			<h3>col-lg-3</h3>
		</div>	
		<div class="col-lg-3 col-xs-3 col-md-12">
			<h3>col-lg-3</h3>
		</div>		
		<div class="col-md-3">
			<h3>col-md-3</h3>
		</div>	
		<div class="col-md-3">
			<h3>col-md-3</h3>
		</div>
	</div>
</div> 

<!-- Example 6 -->
<h1>Offset</h1>
<div class="container">
	<div class="row">
		<div class="col-sm-offset-6 col-sm-6">
			<h3>col-sm-offset-6 and col-sm-6</h3>
		</div>		
	</div>
</div> 


<!-- Example 7 -->
<h1>Visible and Hidden</h1>
<div class="container">
	<div class="row">
		<div class="col-sm-6 hidden-xs">
			<h3>You can only see me on screens xs and bigger</h3>
		</div>	

		<div class="col-sm-6 visible-xs">
			<h3>You can only see me on screens smaller and the same as xs</h3>		
		</div>			
	</div>
</div> 

</body>
</html>