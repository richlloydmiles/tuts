{
	"people" : [{
		"name" : "reeva" , 
		"gender" : "female" , 
		"sport" : "soccer"
	}  , {
		"name" : "franco" , 
		"gender" : "male" , 
		"sport" : "rugby"
	},
	{
		"name" : "dwight" , 
		"gender" : "male" , 
		"sport" : "formula 1"
	}]
}