<footer>
	<h1>Footer 2</h1>
</footer>
</body>
</html>