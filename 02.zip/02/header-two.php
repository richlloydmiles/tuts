<?php
/**
 * Index File for our theme
 * 
 */
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
</head>
<body>
	<header>
		<h1>Header 2</h1>
	</header>