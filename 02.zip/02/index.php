<?php get_header(); ?>
<section>
	<h4>
		Content
	</h4>
	<p>
		<?php get_template_part('content', 'single');?>	</p>
	</section>
	<?php get_sidebar(); ?>
	<?php get_sidebar('two'); ?>

	<?php get_footer(); ?>