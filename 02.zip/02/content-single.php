Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed sequi veniam animi vero eos iure, natus voluptate iste alias, sapiente modi at vel quisquam, aut provident blanditiis cupiditate. Temporibus, et!

<!-- part-1	 -->
<!-- <pre>
	<?php var_dump(get_post('1')); ?>
</pre>
 -->




<!-- part-2 -->
<!-- 
<?php
$post = get_post('1');
$title = $post->post_title;
$content = $post->post_content;
	?>
	<h1>
		<?php echo $title; ?>
	</h1>
	<p>
		<?php echo $content; ?>
	</p>
 -->