<?php
/**
 * Template Name: Hello World
 * 
 */
 ?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
</head>
<body>
<h1>This is an example template</h1>	
</body>
</html>