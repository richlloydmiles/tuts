<?php
/**
 * Index File for our theme
 * 
 */
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
</head>
<body>

	<header>
	<h1><?php echo get_bloginfo();?></h1>
	</header>