<?php get_header(); ?>
<!-- example 1 -->
<h2>For loop</h2>
<pre>
	for($i = 0; i < 10; i ++;) {
	echo 'hello';
}
</pre>
<h2>While loop</h2>
<pre>
	$x = 1; 
	while($x <= 5) {
	echo "The number is: $x <br>";
	$x++;
} 
</pre>
<!-- example 2 -->
<h2>Array Example 1</h2>
<pre>
	$cars = array("Volvo", "BMW", "Toyota");
	echo "I like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";
</pre>

<!-- example 3 -->
<h2>Array Example 2</h2>
<pre>
	$cars = array("Volvo", "BMW", "Toyota");

	for($x = 0; $x < count($cars); $x++) {
	echo $cars[$x];
	echo "<br>";
}
</pre>

<!-- example 4 -->
<h2>Associative Arrays</h2>
<pre>
	$age = array(
	"Peter"=>"35",
	"Ben"=>"37", 
	"Joe"=>"43");

	OR

	$age['Peter'] = "35";
	$age['Ben'] = "37";
	$age['Joe'] = "43";

</pre>

<!-- example 5 -->
<h2>A person</h2>
<pre>

	$person - Name - Age - Email
	Peter		35		peter@wobble.co.za
	Ben		37		ben@wobble.co.za
	Joe		43		joe@wobble.co.za
</pre>


<!-- example 6 -->
<h2>MULTIDIMENSIONAL ARRAYS!!!!!</h2>
<pre>
	$joe = array();
	$person = array(
	array(),
	array(),
	array(),
	$joe,
	);
</pre>

<!-- example 7 -->
<h2>MULTIDIMENSIONAL ARRAYS!!!!!.. in a loop</h2>
<pre>
	$joe = array(
	'name'=>'joe',
	'age'=>'35',
	'email'=>  'joe@wobble.co.za'
	);

	$people = array(
	array('name'=>'peter' , 'age' => '37' , 'email' => 'peter@wobble.co.za'),
	array('name'=>'ben' , 'age' => '43' , 'email' => 'ben@wobble.co.za'),
	$joe,
	);

	for($x = 0; $x < count($people); $x++) {
	echo $people[$x]['name'];
	echo '<br>';
}
</pre>

<!-- example 8 -->
<h2>wut?</h2>
<pre>
	$universe = array(
	array(
	array(),
	array()
	),
	array(
	array(),
	array()
	),
	array(
	array(),
	array()
	),
	array(
	array(),
	array()
	)
	);
</pre>


<!-- example 9 -->
<h2>simple object</h2>
<pre>

	$joe = new Person('joe' , '35' , 'joe@wobble.co.za');
	$ben = new Person('ben' , '37' , 'ben@wobble.co.za');

	echo $joe->name;

</pre>

<!-- example 10 -->
<h2>simple class</h2>
<pre>
	class Person {
	public $name;
	public $age;
	public $email;
}
</pre>

<!-- example 11 -->
<h2>The constructor</h2>
<pre>
	class Person {
		public $name;
		public $age;
		public $email;
		public function __construct($name, $age, $email) {
		$this->name = $name;
		$this->age = $age;
		$this->email = $email;
	}
}
</pre>
<?php get_footer(); ?>
